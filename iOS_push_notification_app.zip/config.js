// Fill these with your VAPID keys after generating
const CONFIG = {
  SERVER_URL: "https://YOUR_DOMAIN/push",
  VAPID_PUBLIC_KEY: "REPLACE_ME"
};
